package com.shape.query;

import lombok.Data;

@Data
public class BbsQuery {
    private String teacherId;
    private String studentId;
}
