package com.shape.query;

import lombok.Data;

@Data
public class LeaveQuery {
    private String teacherId;
    private String studentId;
}
