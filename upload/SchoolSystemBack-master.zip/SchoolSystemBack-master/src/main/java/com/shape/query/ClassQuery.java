package com.shape.query;

import lombok.Data;

@Data
public class ClassQuery {
    private String masterId;
}
