package com.shape.entity;

import lombok.Data;

@Data
public class Class {
    private Integer id;
    private String className;
    private String masterId;
}
