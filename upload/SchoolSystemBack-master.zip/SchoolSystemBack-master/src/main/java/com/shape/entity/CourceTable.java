package com.shape.entity;

import lombok.Data;

@Data
public class CourceTable {
    private Integer id;
    private Integer jie;
    private Integer week;
    private String content;
    private Integer classId;
}
