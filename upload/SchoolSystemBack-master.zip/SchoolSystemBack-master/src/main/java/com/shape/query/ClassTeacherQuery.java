package com.shape.query;

import lombok.Data;

@Data
public class ClassTeacherQuery {
    private String teacherId;
    private Integer classId;
}
