package com.shape.query;

import lombok.Data;

/**
 * 课程表查询对象
 */
@Data
public class CourceTableQuery {
    Integer classId;
}
